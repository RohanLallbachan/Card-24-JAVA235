/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.io.File;

/**
 *
 * @author rohan
 */
public class Card {
  
  
    String name;
    int value;
    String z ;
    
    Card(String n, int v, String f){
        name = n;
        value = v;
        f = z;
    }  
 
}
    

