/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.io.File;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author rohan
 */
public class FinalProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Card [] arr;
        arr = new Card[52];
        // 2
        arr[0] = new Card("clubs",2,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\2_of_clubs.png\"");
        arr[1] = new Card("diamonds",2,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\2_of_diamonds.png\"");
        arr[2] = new Card("hearts",2,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\2_of_hearts.png\"");
        arr[3] = new Card("spades",2,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\2_of_spades.png\"");
        
        //3
        arr[4] = new Card("clubs",3,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\3_of_clubs.png\"");
        arr[5] = new Card("diamonds",3,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\3_of_diamonds.png\"");
        arr[6] = new Card("hearts",3,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\3_of_hearts.png\"");
        arr[7] = new Card("spades",3,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\3_of_spades.png\"");
        
        //4
        arr[8] = new Card("clubs",4,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\4_of_clubs.png\"");
        arr[9] = new Card("diamonds",4,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\4_of_diamonds.png\"");
        arr[10] = new Card("hearts",4,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\4_of_hearts.png\"");
        arr[11] = new Card("spades",4,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\4_of_spades.png\"");
        
        //5
        arr[12] = new Card("clubs",5,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\5_of_clubs.png\"");
        arr[13] = new Card("diamonds",5,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\5_of_diamonds.png\"");
        arr[14] = new Card("hearts",5,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\5_of_hearts.png\"");
        arr[15] = new Card("spades",5,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\5_of_spades.png\"");
        
        //6
        arr[16] = new Card("clubs",6,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\6_of_clubs.png\"");
        arr[17] = new Card("diamonds",6,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\6_of_diamonds.png\"");
        arr[18] = new Card("hearts",6,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\6_of_hearts.png\"");
        arr[19] = new Card("spades",6,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\6_of_spades.png\"");
        
        //7
        arr[20] = new Card("clubs",7,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\7_of_clubs.png\"");
        arr[21] = new Card("diamonds",7,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\7_of_diamonds.png\"");
        arr[22] = new Card("hearts",7,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\7_of_hearts.png\"");
        arr[23] = new Card("spades",7,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\7_of_spades.png\"");
        
        //8
        arr[24] = new Card("clubs",8,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\8_of_clubs.png\"");
        arr[25] = new Card("diamonds",8,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\8_of_diamonds.png\"");
        arr[26] = new Card("hearts",8,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\8_of_hearts.png\"");
        arr[27] = new Card("spades",8,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\8_of_spades.png\"");
        
        //9
        arr[28] = new Card("clubs",9,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\9_of_clubs.png\"");
        arr[29] = new Card("diamonds",9,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\9_of_diamonds.png\"");
        arr[30] = new Card("hearts",9,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\9_of_hearts.png\"");
        arr[31] = new Card("spades",9,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\9_of_spades.png\"");
        
        //10
        arr[32] = new Card("clubs",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\10_of_clubs.png\"");
        arr[33] = new Card("diamonds",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\10_of_diamonds.png\"");
        arr[34] = new Card("hearts",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\10_of_hearts.png\"");
        arr[35] = new Card("spades",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\10_of_spades.png\"");
        
        //ace
        arr[36] = new Card("clubs",1,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\ace_of_clubs.png\"");
        arr[37] = new Card("diamonds",1,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\ace_of_diamonds.png\"");
        arr[38] = new Card("hearts",1,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\ace_of_hearts.png\"");
        arr[39] = new Card("spades",1,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\ace_of_spades.png\"");
        
        //jack
        arr[40] = new Card("clubs",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\jack_of_clubs.png\"");
        arr[41] = new Card("diamonds",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\jack_of_diamonds.png\"");
        arr[42] = new Card("hearts",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\jack_of_hearts.png\"");
        arr[43] = new Card("spades",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\jack_of_spades.png\"");
        
        //queen
        arr[44] = new Card("clubs",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\queen_of_clubs.png\"");
        arr[45] = new Card("diamonds",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\queen_of_diamonds.png\"");
        arr[46] = new Card("hearts",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\queen_of_hearts.png\"");
        arr[47] = new Card("spades",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\queen_of_spades.png\"");
        
        //king
        arr[48] = new Card("clubs",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\king_of_clubs.png\"");
        arr[49] = new Card("diamonds",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\king_of_diamonds.png\"");
        arr[50] = new Card("hearts",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\king_of_hearts.png\"");
        arr[51] = new Card("spades",10,"\"C:\\Users\\rohan\\Downloads\\PlayingCards (2)\\png\\king_of_spades.png\"");
        
        
        
   
          // logic for generating card 
           Random rand=new Random();
           
           Card a = arr[1+rand.nextInt(52)];
           Card b = arr[1+rand.nextInt(52)];
           Card c = arr[1+rand.nextInt(52)];
           Card d = arr[1+rand.nextInt(52)];
           
           
           int w = a.value;
           int x = b.value;
           int y = c.value;
           int z = d.value;
           
           String aw = a.name;
           String ax = b.name;
           String ay = c.name;
           String az = d.name;
           
           File aa = new File(a.z);
           File ab = new File(b.z);
           File ac = new File(c.z);
           File ad = new File(d.z);
          
           
           if(w + x + y + z == 24 || w + x -  y + z == 24 || w + x + y - z == 24 || w - x + y + z == 24 ||
                   w - x - y - z == 24 || w - x +  y - z == 24 || w - x - y + z == 24 || w + x - y - z == 24 || 
                   w * x * y * z == 24 || w * x /  y * z == 24 || w * x * y / z == 24 || w / x * y * z == 24 ||
                   w / x / y / z == 24 || w / x *  y / z == 24 || w / x / y * z == 24 || w * x / y / z == 24 ||
                   w / x + y / z == 24 || w / x -  y / z == 24 || w * x + y * z == 24 || w * x - y * z == 24 ||
                  (w * x) * (y * z) == 24 || (w * x) /  (y * z) == 24 || (w * x) * (y / z) == 24 || (w / x) * (y * z) == 24 ||
                  (w / x) / (y / z) == 24  || (w / x) /  (y * z) == 24 || (w / x) * (y / z) == 24 || (w * x) / (y / z) == 24 ||
                  (w * x) + (y * z) == 24 || (w * x) -  (y * z) == 24 || (w + x) * (y - z) == 24 || (w - x) * (y + z) == 24 ||
                  (w / x) + (y / z) == 24 || (w / x) -  (y / z) == 24 || (w + x) / (y - z) == 24 || (w - x) / (y + z) == 24 ||
                   x - w - z - y == 24 || x - w +  z - y == 24 || x - w - z + y == 24 || x + w - z - y == 24 || 
                   x * w * z * y == 24 || x * w /  z * y == 24 || x * w * z / y == 24 || x / w * z * y == 24 ||
                   x / w / z / y == 24 || x / w *  z / y == 24 || x / w / z * y == 24 || x * w / z / y == 24 ||
                   x / w + z / y == 24 || x / w -  z / y == 24 || x * w + z * y == 24 || x * w - z * y == 24 ||
                  (x * w) * (z * y) == 24 || (x * w) /  (z * y) == 24 || (x * w) * (z / y) == 24 || (x / w) * (z * y) == 24 ||
                  (x / w) / (z / y) == 24  || (x / w) /  (z * y) == 24 || (x / w) * (z / y) == 24 ||(x * w) / (z / y) == 24 ||
                  (x * w) + (z * y) == 24 || (x * w) -  (z * y) == 24 || (x + w) * (z - y) == 24 || (x - w) * (z + y) == 24 ||
                  (x / w) + (z / y) == 24 || (x / w) -  (z / y) == 24 || (x + w) / (z - y) == 24 || (x - w) / (z + y) == 24 ||
                   z - y - x - w == 24 || z - y +  x - w == 24 || z - y - x + w == 24 || z + y - x - w == 24 || 
                   z * y * x * w == 24 || z * y /  x * w == 24 || z * y * x / w == 24 || z / y * x * w == 24 ||
                   z / y / x / w == 24 || z / y *  x / w == 24 || z / y / x * w == 24 || z * y / x / w == 24 ||
                   z / y + x / w == 24 || z / y -  x / w == 24 || z * y + x * w == 24 || z * y - x * w == 24 ||
                  (z * y) * (x * w) == 24 || (z * y) /  (x * w) == 24 || (z * y) * (x / w) == 24 || (z / y) * (x * w) == 24 ||
                  (z / y) / (x / w) == 24  || (z / y) /  (x * w) == 24 || (z / y) * (x / w) == 24 ||(z * y) / (x / w) == 24 ||
                  (z * y) + (x * w) == 24 || (z * y) -  (x * w) == 24 || (z + y) * (x - w) == 24 || (z - y) * (x + w) == 24 ||
                  (z / y) + (x / w) == 24 || (z / y) -  (x / w) == 24 || (z + y) / (x - w) == 24 || (z - y) / (x + w) == 24 ||
                   y - z - w - x == 24 || y - z +  w - x == 24 || y - z - w + w == 24 || y + z - w - x == 24 || 
                   y * z * w * x == 24 || y * z /  w * x == 24 || y * z * w / w == 24 || y / z * w * x == 24 ||
                   y / z / w / x == 24 || y / z *  w / x == 24 || y / z / w * w == 24 || y * z / w / x == 24 ||
                   y / z + w / x == 24 || y / z -  w / x == 24 || y * z + w * w == 24 || y * z - w * x == 24 ||
                  (y * z) * (w * x) == 24 || (y * z) /  (w * x) == 24 || (y * z) * (w / x) == 24 || (y / z) * (w * x) == 24 ||
                  (y / z) / (w / x) == 24  || (y / z) /  (w * x) == 24 || (y / z) * (w / x) == 24 ||(y * z) / (w / x) == 24 ||
                  (y * z) + (w * x) == 24 || (y * z) -  (w * x) == 24 || (y + z) * (w - x) == 24 || (y - z) * (w + x) == 24 ||
                  (y / z) + (w / x) == 24 || (y / z) -  (w / x) == 24 || (y + z) / (w - ) == 24 || (y - z) / (w + x) == 24)
               
               
           
              // else 
                     // System.out.println("try again");
               
   
                   
               
               
               
               
           
           
           
           
              

        
    

