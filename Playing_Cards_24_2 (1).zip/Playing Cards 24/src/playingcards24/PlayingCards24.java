package playingcards24;

import java.util.*;


public class PlayingCards24 {
    
static int sum=0;
static int[] sum()//Method of generating random numbers and displaying
        
{
Random rand=new Random();
int r1=(1+rand.nextInt(13));
int r2=(1+rand.nextInt(13));
int r3=(1+rand.nextInt(13));
int r4=(1+rand.nextInt(13));
System.out.print("The cards issued are:");
switch(r1)
{
case 1 :System.out.print("A");break;
case 11:System.out.print("J");break;
case 12:System.out.print("Q");break;
case 13:System.out.print("K");break;
default:System.out.print(r1);break;
}
switch(r2)
{
case 1 :System.out.print(" A");break;
case 11:System.out.print(" J");break;
case 12:System.out.print(" Q");break;
case 13:System.out.print(" K");break;
default:System.out.print(" "+r2);break;
}
switch(r3)
{
case 1 :System.out.print(" A");break;
case 11:System.out.print(" J");break;
case 12:System.out.print(" Q");break;
case 13:System.out.print(" K");break;
default:System.out.print(" "+r3);break;
}
switch(r4)
{
case 1 :System.out.println(" A");break;
case 11:System.out.println(" J");break;
case 12:System.out.println(" Q");break;
case 13:System.out.println(" K");break;
default:System.out.println(" "+r4);break;
}
int [] s=new int[] {r1,r2,r3,r4};
return s;
}
static int js(int i,int j,int x)

//Confirm the sign of calculation between two numbers
        
{
int m=0;
switch(x)
{
case 0:m=i+j;break;
case 1:m=i-j;break;
case 2:m=i*j;break;
case 3:
m=i/j;if(i%j!=0) m=-1;

//If you can’t divide, just let m=-1 so as to end the cycle directly

break;
}
return m;
}
static String prin(int s1,int s2,int s3,int s4,int x1,int x2,int x3)

//Print the solution expression
        
{
String ch="";
switch(s1)  {
case 1 :System.out.print("A");ch="A";break;
case 11:System.out.print("J");ch="J";break;
case 12:System.out.print("Q");ch="Q";break;
case 13:System.out.print("K");ch="K";break;
default:System.out.print(s1);ch=(String)(s1+"0");break; }
switch(x1)  {
case 0:System.out.print("+");ch+="+";break;
case 1:System.out.print("-");ch+="-";break;
case 2:System.out.print("*");ch+="*";break;
case 3:System.out.print("/");ch+="/";break; }
switch(s2)  {
case 1 :System.out.print("A");ch+="A";break;
case 11:System.out.print("J");ch+="J";break;
case 12:System.out.print("Q");ch+="Q";break;
case 13:System.out.print("K");ch+="K";break;
default:System.out.print(s2);ch+=(String)(s2+"");break; }
switch(x2)  {
case 0:System.out.print("+");ch+="+";break;
case 1:System.out.print("-");ch+="-";break;
case 2:System.out.print("*");ch+="*";break;
case 3:System.out.print("/");ch+="/";break; }
switch(s3)  {
case 1 :System.out.print("A");ch+="A";break;
case 11:System.out.print("J");ch+="J";break;
case 12:System.out.print("Q");ch+="Q";break;
case 13:System.out.print("K");ch+="K";break;
default:System.out.print(s3);ch+=(String)(s3+"");break; }
switch(x3)  {
case 0:System.out.print("+");ch+="+";break;
case 1:System.out.print("-");ch+="-";break;
case 2:System.out.print("*");ch+="*";break;
case 3:System.out.print("/");ch+="/";break; }
switch(s4)  {
case 1 :System.out.println("A");ch+="A";break;
case 11:System.out.println("J");ch+="J";break;
case 12:System.out.println("Q");ch+="Q";break;
case 13:System.out.println("K");ch+="K";break;
default:System.out.println(s4);ch+=(String)(s4+"");break;   }

System.out.println("				"+ch);
return ch;
}

static String[] con(int s[])    {
boolean flag=false;
String[] ch=new String [100];
int js1,js2,js3=0;
for(int i = 0;i<4;i++)  {	
for(int j=0;j<4;j++)    
{
if(i!=j)    {
for(int k=0;k<4;k++)    {
if(i!=j&&j!=k&&i!=k)    {
for(int l=0;l<4;l++)    {
if(i!=j&&j!=k&&k!=l&&i!=k&&i!=l&&j!=l)  {
for(int x1=0;x1<3;x1++) {
for(int x2=0;x2<3;x2++) {
for(int x3=0;x3<3;x3++) {
js1=js(s[i],s[j],x1);
if(js1==-1) continue;
js2=js(js1,s[k],x2);
if(js2==-1) continue;
js3=js(js2,s[l],x3);
if(js3==-1) continue;
if(js3!=-1) {
if(js3==24) {
ch[sum]=prin(s[i],s[j],s[k],s[l],x1,x2,x3);
flag=true;
sum++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
if(flag==false) {
System.out.println("There is no set of solutions to make it \"24 points\"");    
    }
return ch;
    }
public static void main(String[] args)  {
boolean f=false;
Scanner in=new Scanner(System.in);
while(!f)       {
int [] s=sum();
con(s);
System.out.println();
System.out.println("Continue (1) or end (0)");
if(in.nextInt()==1)
{f=false;}
else
{f=true;}
                }		
            }
    }